package com.royal.web.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.royal.web.entity.Bakery;
import com.royal.web.repository.BakeryRepo;

@Service
public class BakeryService {
private final BakeryRepo repository;
	
	public BakeryService(BakeryRepo repository) {
		this.repository = repository;
	}
	
	public List<Bakery> listAll() {
		return repository.findAll();
	}
	
	public Bakery get(int id) {
		return repository.findById(id);
	}
	
	public void save(Bakery bakery) {
		repository.save(bakery);
	}
	
	public void update(Bakery bakery) {
		repository.update(bakery);
	}
	
	public void deleteById(int id) {
		repository.deleteById(id);
	}
}
