package com.royal.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.royal.web.entity.Bakery;
import com.royal.web.service.BakeryService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/bakery")
public class BakeryController {
	
	private final BakeryService bakeryService;
	
	public BakeryController(BakeryService bakeryService) {
		this.bakeryService = bakeryService;
	}
	
	@GetMapping
	public String list(Model model) {
		model.addAttribute("items", bakeryService.listAll());
		return "bakery_items/items";
	}
	
	@GetMapping("/add")
	public String showForm(Model model) {
		model.addAttribute("item", new Bakery());
		return "bakery_items/form";
	}
	
	@PostMapping("/save")
	public String save(@Valid @ModelAttribute Bakery bakery) {
		bakeryService.save(bakery);
		return "redirect:/bakery";
	}
	
	@GetMapping("/view/{id}")
	public String view(@PathVariable int id, Model model) {
		model.addAttribute("item", bakeryService.get(id));
		return "bakery_items/view";
	}
	
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable int id, Model model) {
		model.addAttribute("item", bakeryService.get(id));
		return "bakery_items/form";
	}
	
	@PostMapping("/update")
	public String update(@Valid @ModelAttribute Bakery bakery) {
		bakeryService.update(bakery);
		return "redirect:/bakery";
	}
	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable int id) {
		bakeryService.deleteById(id);
		return "redirect:/bakery";
	}
}
