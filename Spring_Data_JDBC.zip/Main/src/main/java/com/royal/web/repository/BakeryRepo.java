package com.royal.web.repository;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.royal.web.entity.Bakery;

@Repository
public class BakeryRepo {
	
	private final JdbcTemplate jdbcTemplate;
	
	public BakeryRepo(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	private final RowMapper<Bakery> rowMapper = (rs, rowNum) -> {
		Bakery bakery = new Bakery();
		bakery.setId(rs.getInt("id"));
		bakery.setName(rs.getString("name"));
		bakery.setType(rs.getString("type"));
		bakery.setPrice(rs.getDouble("price"));
		
		return bakery;
	};
	
	public List<Bakery> findAll() {
		return jdbcTemplate.query("SELECT * FROM bakery", rowMapper);
	}
	
	public Bakery findById(int id) {
		return jdbcTemplate.queryForObject("SELECT * FROM bakery WHERE id = ?", rowMapper, id);
	}
	
	public void save(Bakery bakery) {
		jdbcTemplate.update("INSERT INTO bakery (name, type, price) VALUES (?, ?, ?)", bakery.getName(), bakery.getType(), bakery.getPrice());
	}
	
	public void update(Bakery bakery) {
		jdbcTemplate.update("UPDATE bakery SET name = ?, type = ?, price = ? WHERE id = ?", bakery.getName(), bakery.getType(), bakery.getPrice(), bakery.getId());
	}
	
	public void deleteById(int id) {
		jdbcTemplate.update("DELETE FROM bakery WHERE id = ?", id);
	}
}
